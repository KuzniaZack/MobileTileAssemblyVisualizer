import React, { Component } from "react";
import { Platform, StyleSheet, FlatList, Text, View, TextInput, KeyboardAvoidingView, ScrollView} from "react-native";

import Tile from './components/tile.js'
import Box from './components/box.js'


export default class App extends Component {

  state = {
    GridListItems: [
      { key: 1, data: "S", top: '', right: 'B', bottom: 'R', left: ''},
      { key: 1, data: "B", top: '', right: 'B', bottom: '0', left: 'B'},
    ],
    numberColumns: 5,
    maxKey: 2,
    column3counter: 2,
    column2counter: 0,
    column4counter: 0,
    column3LeftBorder: '1',
    column3TopBorder: 0,

  };


  constructor(props) {

       super(props)
      Obj = new Tile();
     }

  handleChangeColumnNumber = (num) => {

    if(num === ''){
      return;
    }

    if(num !== '3' && num !== '4' && num !== '5' && num !== '6' && num !== '7' && num !== '8'){
      alert("please pick a number between 3 and 8");
      return;
    }

    this.setState({numberColumns: num});
    this.setState({GridListItems: [
      { key: 1, data: "S", top: '', right: 'B', bottom: 'R', left: ''},
      { key: 1, data: "B", top: '', right: 'B', bottom: '0', left: 'B'},
    ],});
    this.setState({maxKey: 2});
    this.setState({column3counter: 2});
    this.setState({column2counter: 0});
    this.setState({column4counter: 0});

  }

  handleAddTile = (num) => {

    if(this.state.numberColumns === 5 && num > 79){
      alert("full grid reached");
      return;
    }

    if(this.state.numberColumns === '4' && num > 31){
      alert("full grid reached");
      return;
    }

    if(this.state.numberColumns === '3' && num > 11){
      alert("full grid reached");
      return;
    }

    if(num < 2){
      return;
    }

    var array = [...this.state.GridListItems];
    var key = num + 1;
    var data = 0;
    var top = '';
    var right = '';
    var bottom = '';
    var left = '';
    var col3 = this.state.column3counter;
    var col2 = this.state.column2counter;
    var col4 = this.state.column4counter;
    var col3tb = this.state.column3TopBorder;


    if(key % this.state.numberColumns === 1){
      data = 'R';
      top = 'R';
      bottom = 'R';
      right = '1';
    }else if(this.state.maxKey <= this.state.numberColumns){
      data = 'B';
      left = 'B';
      right = 'B';
      bottom = '0';

    }else if(key % this.state.numberColumns === 2){
      if(col2 === 0){
        data = 1;
        left = '1';
        right = '0';
        bottom = '1';
        top = '0';
        this.setState({column2counter: 1})
      }
      if(col2 === 1){
        data = 0;
        left = '1';
        right = '1';
        bottom = '0';
        top = '1';

        this.setState({column2counter: 0})
      }

    }else if(key % this.state.numberColumns === 3){
      if(col3 === 3){
        data = 1;
        left = this.findLeftBorder(this.state.maxKey);
        top = this.findTopBorder(this.state.numberColumns);
        bottom = this.findBottomBorder(left, top);
        right = this.findRightBorder(left, top);

        this.setState({column3counter: 4})
      }
      if(col3 === 4){
        data = 1;
        left = this.findLeftBorder(this.state.maxKey);
        top = this.findTopBorder(this.state.numberColumns);
        bottom = this.findBottomBorder(left, top);
        right = this.findRightBorder(left, top);

        this.setState({column3counter: 1})
      }
      if(col3 === 1){
        data = 0;
        left = this.findLeftBorder(this.state.maxKey);
        top = this.findTopBorder(this.state.numberColumns);
        bottom = this.findBottomBorder(left, top);
        right = this.findRightBorder(left, top);
        this.setState({column3counter: 2})
      }
      if(col3 === 2){
        data = 0;
        left = this.findLeftBorder(this.state.maxKey);
        top = this.findTopBorder(this.state.numberColumns);
        bottom = this.findBottomBorder(left, top);
        right = this.findRightBorder(left, top);
        this.setState({column3counter: 3})
      }

    }else if(key % this.state.numberColumns === 4){
      if(col4 === 0){
        left = this.findLeftBorder(this.state.maxKey);
        top = this.findTopBorder(this.state.numberColumns);
        bottom = this.findBottomBorder(left, top);
        right = this.findRightBorder(left, top);
        if(key > 20){
          data = 0;
          left = this.findLeftBorder(this.state.maxKey);
          top = this.findTopBorder(this.state.numberColumns);
          bottom = this.findBottomBorder(left, top);
          right = this.findRightBorder(left, top);
        }
        this.setState({column4counter: 1})
      }
      if(col4 === 1){
        left = this.findLeftBorder(this.state.maxKey);
        top = this.findTopBorder(this.state.numberColumns);
        bottom = this.findBottomBorder(left, top);
        right = this.findRightBorder(left, top);
        if(key > 20){
          data = 0;
          left = this.findLeftBorder(this.state.maxKey);
          top = this.findTopBorder(this.state.numberColumns);
          bottom = this.findBottomBorder(left, top);
          right = this.findRightBorder(left, top);
        }
        this.setState({column4counter: 2})
      }
      if(col4 === 2){
        left = this.findLeftBorder(this.state.maxKey);
        top = this.findTopBorder(this.state.numberColumns);
        bottom = this.findBottomBorder(left, top);
        right = this.findRightBorder(left, top);
        if(key > 20){
          data = 0;
          left = this.findLeftBorder(this.state.maxKey);
          top = this.findTopBorder(this.state.numberColumns);
          bottom = this.findBottomBorder(left, top);
          right = this.findRightBorder(left, top);
        }
        this.setState({column4counter: 3})
      }
      if(col4 === 3){
        if(key > 20){
          data = 1;
          left = this.findLeftBorder(this.state.maxKey);
          top = this.findTopBorder(this.state.numberColumns);
          bottom = this.findBottomBorder(left, top);
          right = this.findRightBorder(left, top);
        }
        this.setState({column4counter: 4})
      }
      if(col4 === 4){
        if(key > 20){
          data = 1;
          left = this.findLeftBorder(this.state.maxKey);
          top = this.findTopBorder(this.state.numberColumns);
          bottom = this.findBottomBorder(left, top);
          right = this.findRightBorder(left, top);
        }
        this.setState({column4counter: 5})
      }
      if(col4 === 5){
        if(key > 20){
          data = 1;
          left = this.findLeftBorder(this.state.maxKey);
          top = this.findTopBorder(this.state.numberColumns);
          bottom = this.findBottomBorder(left, top);
          right = this.findRightBorder(left, top);
        }
        this.setState({column4counter: 6})
      }
      if(col4 === 6){
        if(key > 20){
          data = 1;
          left = this.findLeftBorder(this.state.maxKey);
          top = this.findTopBorder(this.state.numberColumns);
          bottom = this.findBottomBorder(left, top);
          right = this.findRightBorder(left, top);
        }
        this.setState({column4counter: 7})
      }
      if(col4 === 7){
        if(key > 20){
          data = 0;
          left = this.findLeftBorder(this.state.maxKey);
          top = this.findTopBorder(this.state.numberColumns);
          bottom = this.findBottomBorder(left, top);
          right = this.findRightBorder(left, top);
        }
        this.setState({column4counter: 0})
      }
    }else if(key % this.state.numberColumns === 5){
      left = this.findLeftBorder(this.state.maxKey);
      top = this.findTopBorder(this.state.numberColumns);
      bottom = this.findBottomBorder(left, top);
      right = this.findRightBorder(left, top);

      if(this.state.numberColumns === '8'){
        if(key > 64 && key < 128 || key > 192 && key < 256 || key > 320 && key < 384 || key > 448 && key < 512 || key > 576 && key < 640 || key > 704 && key < 768 || key > 832 && key < 896 || key > 960 && key < 1024){
          data = 1;
          left = this.findLeftBorder(this.state.maxKey);
          top = this.findTopBorder(this.state.numberColumns);
          bottom = this.findBottomBorder(left, top);
          right = this.findRightBorder(left, top);
        }
      }

      if(this.state.numberColumns === '6'){
        left = this.findLeftBorder(this.state.maxKey);
        top = this.findTopBorder(this.state.numberColumns);
        bottom = this.findBottomBorder(left, top);
        right = this.findRightBorder(left, top);
        if(key > 50 && key < 100){
          data = 1;
          left = this.findLeftBorder(this.state.maxKey);
          top = this.findTopBorder(this.state.numberColumns);
          bottom = this.findBottomBorder(left, top);
          right = this.findRightBorder(left, top);
        }

        if(key > 150 && key <200){
          data =1;
          left = this.findLeftBorder(this.state.maxKey);
          top = this.findTopBorder(this.state.numberColumns);
          bottom = this.findBottomBorder(left, top);
          right = this.findRightBorder(left, top);
        }
      }

      if(this.state.numberColumns === '7'){
        left = this.findLeftBorder(this.state.maxKey);
        top = this.findTopBorder(this.state.numberColumns);
        bottom = this.findBottomBorder(left, top);
        right = this.findRightBorder(left, top);
        if(key > 60 && key < 116 || key > 167 && key < 223 || key > 281 && key < 337 || key > 393){
          data = 1;
          left = this.findLeftBorder(this.state.maxKey);
          top = this.findTopBorder(this.state.numberColumns);
          bottom = this.findBottomBorder(left, top);
          right = this.findRightBorder(left, top);
        }

      }


    }else if(key % this.state.numberColumns === 6){
      left = this.findLeftBorder(this.state.maxKey);
      top = this.findTopBorder(this.state.numberColumns);
      bottom = this.findBottomBorder(left, top);
      right = this.findRightBorder(left, top);

      if(this.state.numberColumns === '8'){
        left = this.findLeftBorder(this.state.maxKey);
        top = this.findTopBorder(this.state.numberColumns);
        bottom = this.findBottomBorder(left, top);
        right = this.findRightBorder(left, top);
        if(key > 128 && key < 256 || key > 384 && key < 512 || key > 640 && key < 768 || key > 896 && key < 1024){
          data = 1;
          left = this.findLeftBorder(this.state.maxKey);
          top = this.findTopBorder(this.state.numberColumns);
          bottom = this.findBottomBorder(left, top);
          right = this.findRightBorder(left, top);
        }
      }

      if(this.state.numberColumns === '7'){
        left = this.findLeftBorder(this.state.maxKey);
        top = this.findTopBorder(this.state.numberColumns);
        bottom = this.findBottomBorder(left, top);
        right = this.findRightBorder(left, top);
        if(key > 116 && key < 228 || key > 340){
          data = 1;
          left = this.findLeftBorder(this.state.maxKey);
          top = this.findTopBorder(this.state.numberColumns);
          bottom = this.findBottomBorder(left, top);
          right = this.findRightBorder(left, top);
        }
      }


    }else if(key % this.state.numberColumns === 7){
      left = this.findLeftBorder(this.state.maxKey);
      top = this.findTopBorder(this.state.numberColumns);
      bottom = this.findBottomBorder(left, top);
      right = this.findRightBorder(left, top);

      if(key > 256 && key < 512 || key > 768 && key < 1024){
        data = 1;
        left = this.findLeftBorder(this.state.maxKey);
        top = this.findTopBorder(this.state.numberColumns);
        bottom = this.findBottomBorder(left, top);
        right = this.findRightBorder(left, top);
      }


    }
    else if(key % this.state.numberColumns === 0){
      if(this.state.numberColumns === 5){
        left = this.findLeftBorder(this.state.maxKey);
        top = this.findTopBorder(this.state.numberColumns);
        bottom = this.findBottomBorder(left, top);
        right = this.findRightBorder(left, top);
        if(key > 40){
          data = 1;
          left = this.findLeftBorder(this.state.maxKey);
          top = this.findTopBorder(this.state.numberColumns);
          bottom = this.findBottomBorder(left, top);
          right = this.findRightBorder(left, top);
        }
      }

      if(this.state.numberColumns === '8'){
        left = this.findLeftBorder(this.state.maxKey);
        top = this.findTopBorder(this.state.numberColumns);
        bottom = this.findBottomBorder(left, top);
        right = this.findRightBorder(left, top);
        if(key > 510){
          data = 1;
          left = this.findLeftBorder(this.state.maxKey);
          top = this.findTopBorder(this.state.numberColumns);
          bottom = this.findBottomBorder(left, top);
          right = this.findRightBorder(left, top);
        }
      }

      if(this.state.numberColumns === '7'){
        left = this.findLeftBorder(this.state.maxKey);
        top = this.findTopBorder(this.state.numberColumns);
        bottom = this.findBottomBorder(left, top);
        right = this.findRightBorder(left, top);
        if(key > 228){
          data = 1;
          left = this.findLeftBorder(this.state.maxKey);
          top = this.findTopBorder(this.state.numberColumns);
          bottom = this.findBottomBorder(left, top);
          right = this.findRightBorder(left, top);
        }
      }

      if(this.state.numberColumns === '6'){
        left = this.findLeftBorder(this.state.maxKey);
        top = this.findTopBorder(this.state.numberColumns);
        bottom = this.findBottomBorder(left, top);
        right = this.findRightBorder(left, top);
        if(key > 95){
          data = 1;
          left = this.findLeftBorder(this.state.maxKey);
          top = this.findTopBorder(this.state.numberColumns);
          bottom = this.findBottomBorder(left, top);
          right = this.findRightBorder(left, top);
        }
      }

      if(this.state.numberColumns === '5'){
        left = this.findLeftBorder(this.state.maxKey);
        top = this.findTopBorder(this.state.numberColumns);
        bottom = this.findBottomBorder(left, top);
        right = this.findRightBorder(left, top);
        if(key > 40){
          data = 1;
          left = this.findLeftBorder(this.state.maxKey);
          top = this.findTopBorder(this.state.numberColumns);
          bottom = this.findBottomBorder(left, top);
          right = this.findRightBorder(left, top);
        }
      }

      if(this.state.numberColumns === '4'){
        left = this.findLeftBorder(this.state.maxKey);
        top = this.findTopBorder(this.state.numberColumns);
        bottom = this.findBottomBorder(left, top);
        right = this.findRightBorder(left, top);
        if(key > 19){
          data = 1;
          left = this.findLeftBorder(this.state.maxKey);
          top = this.findTopBorder(this.state.numberColumns);
          bottom = this.findBottomBorder(left, top);
          right = this.findRightBorder(left, top);
        }
      }

      if(this.state.numberColumns === '3'){
        left = this.findLeftBorder(this.state.maxKey);
        top = this.findTopBorder(this.state.numberColumns);
        bottom = this.findBottomBorder(left, top);
        right = this.findRightBorder(left, top);
        if(key > 6){
          data = 1;
          left = this.findLeftBorder(this.state.maxKey);
          top = this.findTopBorder(this.state.numberColumns);
          bottom = this.findBottomBorder(left, top);
          right = this.findRightBorder(left, top);
        }
      }
    }else {

    }
    array.push({key: key, data: data, top: top, right: right, bottom: bottom, left: left});
    this.setState({GridListItems: array})
    this.setState({maxKey: key}, ()=> console.log());
    this.setState({column3TopBorder: col3tb + 1})

    if(col3tb === '3'){
      this.setState({column3TopBorder: 0})
    }

    if(this.state.column3LeftBorder === '0'){
      this.setState({column3LeftBorder: '1'})
    }else {
      this.setState({column3LeftBorder: '0'})
    }


  }

  handleRemoveTile = (num) => {

    var key = num - 1;
    var col3 = this.state.column3counter;
    var col2 = this.state.column2counter;
    var col4 = this.state.column4counter;

    if(num < 3){
      return;
    }

    if(key % this.state.numberColumns === 1){

      col2 = col2 - 1;
      if(col2 === -1){
        col2 = 1;
      }
    } else if(key % this.state.numberColumns === 2){
      col3 = col3 - 1;
      if(col3 === 0){
        col3 = 4;
      }
    } else if(this.state.maxKey % this.state.numberColumns === 4){
      col4 = col4 - 1;
      if(col4 === -1){
        col4 = 7;
      }
    }

    var array = [...this.state.GridListItems];
    array.pop();
    this.setState({GridListItems: array})
    this.setState({maxKey: key}, ()=> console.log());
    this.setState({column2counter: col2}, ()=> console.log());
    this.setState({column3counter: col3}, ()=> console.log());
    this.setState({column4counter: col4}, ()=> console.log());


  }

  handleGenerateFullGrid = (num) => {

    if(this.state.numberColumns === 5){
      for(i = num; i < 80; i++){
        setTimeout(() => {  this.handleAddTile(this.state.maxKey); }, 50);
      }
    }

    if(this.state.numberColumns === '8'){
      for(i = num; i < 1024; i++){
        setTimeout(() => {  this.handleAddTile(this.state.maxKey); }, 50);
      }
    }

    if(this.state.numberColumns === '7'){
      for(i = num; i < 448; i++){
        setTimeout(() => {  this.handleAddTile(this.state.maxKey); }, 50);
      }
    }

    if(this.state.numberColumns === '6'){
      for(i = num; i < 192; i++){
        setTimeout(() => {  this.handleAddTile(this.state.maxKey); }, 50);
      }
    }

    if(this.state.numberColumns === '5'){
      for(i = num; i < 80; i++){
        setTimeout(() => {  this.handleAddTile(this.state.maxKey); }, 50);
      }
    }

    if(this.state.numberColumns === '4'){
      for(i = num; i < 32; i++){
        setTimeout(() => {  this.handleAddTile(this.state.maxKey); }, 50);
      }
    }

    if(this.state.numberColumns === '3'){
      for(i = num; i < 12; i++){
        setTimeout(() => {  this.handleAddTile(this.state.maxKey); }, 50);
      }
    }


  }

  findLeftBorder = (numColumns) => {
    return this.state.GridListItems[this.state.maxKey - 1].right;
  }

  findRightBorder = (left, top) => {

    if(left === '1' && top === '1'){
      return '1';
    } else {
      return '0';
    }


  }

  findBottomBorder = (left, top) => {
    if(left === '0' && top === '0'){
      return '0';
    }else if(left === '1' && top === '1'){
      return '0';
    }else{
      return '1'
    }

  }

  findTopBorder = (numColumns) => {
    var num = parseInt(numColumns);
    return this.state.GridListItems[this.state.maxKey - num].bottom;

  }




  render() {

     return (
       <View style={styles.container}>
        <ScrollView maximumZoomScale= {4}
          minimumZoomScale = {.33}
          horizontal={true} contentContainerStyle={styles.testing}>
         <FlatList style={{top: 50}}
            data={ this.state.GridListItems }
            renderItem={ ({item}) =>
              <View>
               <Tile placeholder={item.data} top={item.top} right={item.right} bottom={item.bottom} left={item.left}> </Tile>
              </View> }
            numColumns={this.state.numberColumns}
            key={this.state.numberColumns}
          />
         </ScrollView>
         <KeyboardAvoidingView behavior={Platform.OS == "ios" ? "padding" : "height"}>
           <View style={styles.buttons}>

            <TextInput style = {styles.input}
                 placeholder = "Enter number of columns (default is 5)"
                 onChangeText = {this.handleChangeColumnNumber}/>

            </View>
         </KeyboardAvoidingView>

         <View style={styles.buttons}>
          <Box placeholder='-' onPress={()=>this.handleRemoveTile(this.state.maxKey)}> </Box>
          <Box placeholder='full grid' onPress={()=>this.handleGenerateFullGrid(this.state.maxKey)}> </Box>
          <Box placeholder='+' onPress={()=>this.handleAddTile(this.state.maxKey)}> </Box>
         </View>

       </View>


    );
  }

}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    backgroundColor: "#ffffe0",
    alignItems: "center",
  },
  headerText: {
    fontSize: 20,
    textAlign: "center",
    margin: 10,
    fontWeight: "bold"
  },
  GridViewContainer: {
   flex:1,
   justifyContent: 'center',
   alignItems: 'center',
   height: 100,
   margin: 5,
},
GridViewTextLayout: {
   fontSize: 20,
   fontWeight: 'bold',
   justifyContent: 'center',
   color: '#fff',
   padding: 10,
 },
 buttons: {
   flexDirection: 'row',
 },
 input: {
      margin: 15,
      height: 40,
      borderColor: '#7a42f4',
      borderWidth: 1
   },
   testing: {

   }
});
