import React from 'react';
import { StyleSheet, Text, View, ImageBackground, TouchableOpacity } from 'react-native';
import PropTypes from 'prop-types';

export default class Tile extends React.Component {

      static propTypes = {
        top: PropTypes.string,
        right: PropTypes.string,
        bottom: PropTypes.string,
        left: PropTypes.string,
      };

       state = {

       };





  setBorders = (top, right, bottom, left) => {
    this.setState({top: top});
    this.setState({right: right});
    this.setState({bottom: bottom});
    this.setState({left: left});
  }

  componentDidMount(){
    this.setBorders(this.state.top, this.state.right, this.state.bottom, this.state.left);
  }

  render(){

    var { top, right, bottom, left } = this.state;

    return (
        <View style={styles.tile}>
          <Text style={styles.topBorderText}>{this.props.top}</Text>
          <Text style={styles.leftBorderText}>{this.props.left}</Text>
          <Text style={styles.rightBorderText}>{this.props.right}</Text>
          <Text style={styles.bottomBorderText}>{this.props.bottom}</Text>
          <Text style={styles.tileText}>{this.props.placeholder}</Text>

        </View>
    );
  }
}

const styles = StyleSheet.create({

  tileText: {
    flex: 1,
    fontSize: 20,
    lineHeight: 35,
    textAlign: 'center',
    position: 'absolute',
    paddingLeft: 28,
    paddingTop: 15

  },
  topBorderText: {
    textAlign: 'center',
    fontSize: 10
  },
  leftBorderText: {
    position: 'absolute',
    paddingTop: 29,
    paddingLeft: 5,
    fontSize: 10
  },
  rightBorderText: {
    position: 'absolute',
    paddingTop: 29,
    paddingLeft: 59,
    fontSize: 10
  },
  bottomBorderText: {
    position: 'absolute',
    fontSize: 10,
    paddingTop: 58,
    paddingLeft: 33
  },
  tile:{
   width: 80,
   height: 80,
   backgroundColor: '#d3d3d3',
   borderWidth: 3,
   borderTopColor: 'black',
   borderRightColor: 'black',
   borderBottomColor: 'black',
   borderLeftColor: 'black'
 }
});
