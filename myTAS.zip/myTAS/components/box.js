import React from 'react';
import { StyleSheet, Text, View, ImageBackground, TouchableOpacity } from 'react-native';

export default class Box extends React.Component {

  render(){
    return (
        <View style={styles.box}>
          <TouchableOpacity style={{flex: 1}} onPress={this.props.onPress}>
            <Text style={styles.boxText}>{this.props.placeholder}</Text>
          </TouchableOpacity>
        </View>
    );
  }
}

const styles = StyleSheet.create({
  box: {
    width: 150,
    height: 65,
    backgroundColor: '#d3d3d3',
    borderWidth: 1,
    borderColor: 'black'
  },
  boxText: {
    flex: 1,
    fontSize: 20,
    lineHeight: 55,
    textAlign: 'center',
  },
});
