import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, Text, View, ImageBackground, TouchableOpacity, Linking } from 'react-native';

export default class moreInfo extends React.Component {

  render(){
    return (
        <View style={styles.box}>

            <Text> “Self-assembly is the process during which a collection of relatively simple components,
             starting in a disorganized state, autonomously combine into a more complex structure. During self-assembly,
              there is no external guidance or direction, and the self-assembling components experience only local interactions
               and typically obey a simple set of rules that govern how they combine.”
                from http://self-assembly.net/wiki/index.php?title=Main_Page
            </Text>

            <Text></Text>

            <Text style={styles.link} onPress={ ()=> Linking.openURL('http://self-assembly.net/wiki/index.php?title=Main_Page') } >
            Click Here To visit the self assembly wiki.</Text>

        </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffe0',
    alignItems: 'center',
    justifyContent: 'center',
  },
  link:{
    color: 'blue',
  }
  });
